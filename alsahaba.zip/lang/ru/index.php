<?php 

return [
	"direction"=>"LTR",
	"lang"=>"ru",
	"flag"=>"ru",
	"title"=>"Pусский",
	
];
