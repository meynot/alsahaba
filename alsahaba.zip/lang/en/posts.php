<?php

return [

	"header_browse"=>"Brows Posts",
	"header_create"=> "Create new post",
	"header_delete"=> "Delete post",
	"warn_delete"=> "Are you sure you want to delete this Post",

	"datafield_title"=>"Title",
	"datafield_short"=>"Intro",
	"datafield_body"=>"Body",
	"placeholder_body"=> "Pleast type text in here<br />",
	"datafield_is_published" => "Published",
	"datafield_is_featured" => "Featured",
	"datafield_is_pinned" => "Pinned",
	"datafield_is_commentable" => "Commentable",
	"datafield_has_roles" => "Roles",
	"datafield_is_editable" => "Editable",
	"datafield_is_deleteable" => "Deletable",


	
];