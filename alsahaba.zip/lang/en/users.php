<?php

return [
	'header_browse'=>'Browse users',
	'header_create'=>'Create user',
	'header_delete'=>'Delete user',
	
	
	
	'datafield_name'=> 'Name',
	
	'datafield_password_confirmation'=>'Confirm Password',
	'datafield_password'=>'Password',
	
	'datafield_email'=>' Email',
	'datafield_is_active'=> 'Active',
	'datafield_roles'=> 'Roles',
	
	'datafield_facebook'=> 'Facebook account',
	'datafield_twitter'=>'Twitter Account',
	'datafield_instagram'=>'Instagram',

	'warn_delete'=>'Are you sure from deleting this',
	
];