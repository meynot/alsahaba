<?php 

return [
	"direction"=>"LTR",
	"lang"=>"en",
	"flag"=>"us",
	"title"=>"English",
	
	"action_create"=> "Create",
	"action_edit"=> "Edit",
	"action_delete"=> "Delete",
	"action_cancel"=> "Cancel",
	"action_save"=> "Save",
	
	
	"no_records_found"=> "No data found",
	
];