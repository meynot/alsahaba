<?php

return [
	"signout"=>"Sign out",
	"search"=>"Find",
	"breadcrumbs_dashboard"=>"Dashboard",
	
	"sidebar_dashboard"=>"Dashboard",
	"sidebar_posts_browse"=>"Browse posts",
	"sidebar_users_browse"=> "Browse Users",
	"sidebar_settings"=>"Settings",
	
	
];