<?php


return [
	'navbar_home'=>'Home',
	'navbar_abountus'=>'About us',
	'navbar_sahaba_cards'=>'Sahaba cards',
		'navbar_ten_promised_paradise'=>'Ten Promised Paradise',
		'navbar_most_hadeeth_narrators'=>'Most hadeeth narrators',
		'navbar_find_sahabi'=>'Find Sahabi',
	
	'navbar_sahaba_interducing'=>'Sahaba Info',
	'navbar_contactus'=>'Contact us',
	
	
];