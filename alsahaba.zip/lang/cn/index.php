<?php 

return [
	"direction"=>"LTR",
	"lang"=>"cn",
	"flag"=>"cn",
	"title"=>"汉语",
	
];
