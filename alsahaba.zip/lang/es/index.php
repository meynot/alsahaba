<?php 

return [
	"direction"=>"LTR",
	"lang"=>"es",
	"flag"=>"es",
	"title"=>"Español",
	
];
