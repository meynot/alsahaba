<?php


return [
	'navbar_home'=>'الرئيسية',
	'navbar_abountus'=>'من نحن',
	'navbar_sahaba_cards'=>'كروت الصخابة',
		'navbar_ten_promised_paradise'=>'العشرة المبشرين بالجنة',
		'navbar_most_hadeeth_narrators'=>'مكثرين الحديث',
		'navbar_find_sahabi'=>'ابحث عن صحابي',
	
	'navbar_sahaba_interducing'=>'تراجم الصحابة',
	'navbar_contactus'=>'اتصل بنا',
	
	
	
	
	
	
];