<?php 

return [
	"direction"=>"LTR",
	"lang"=>"tr",
	"flag"=>"tr",
	"title"=>"Türkçe",
	
];
