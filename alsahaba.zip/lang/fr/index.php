<?php 

return [
	"direction"=>"LTR",
	"lang"=>"fr",
	"flag"=>"fr",
	"title"=>"français",
	
];
