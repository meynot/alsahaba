@extends('backend/dashboard/layouts/app')

@section('breadcrumb')
   @lang('backend.breadcrumbs_dashboard')
@endsection

@section('content')
<div class="card">
	<div class="card-header">Welcome onboard</div>
	<div class="card-body">
	<div>TODO</div>
	Reports should be add here for posts, files to download, downloads, views ..etc
	</div>
	<div class="card-footer">
	</div>
</div>
@endsection