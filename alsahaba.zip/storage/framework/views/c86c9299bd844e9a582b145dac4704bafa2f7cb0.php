


<?php $__env->startSection('breadcrumb'); ?>
   <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('backend.breadcrumbs_dashboard'); ?></a> / <a href="<?php echo e(route('posts.index')); ?>"><?php echo app('translator')->get('posts.header_browse'); ?></a> / <?php echo app('translator')->get('posts.header_create'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<style>
.cke_editable {
	padding: 1rem;
}
</style>
<div class="card">
	<div class="card-header"><h3 class="float-start"><?php echo app('translator')->get('posts.header_create'); ?></h3><div class="float-end"></div></div>
	<form method="POST" action="<?php echo e(route('posts.store')); ?>">
	<?php echo csrf_field(); ?>
	<div class="card-body">
		<div class="form-floating mb-1">
		  <input type="text" class="form-control" id="ititle" name="title" value="<?php echo e(old('title') ?? ''); ?>" placeholder="<?php echo app('translator')->get('posts.placeholder_title'); ?>">
		  <label for="ititle"><?php echo app('translator')->get('posts.datafield_title'); ?></label>
		  <div class="invalid-feedback"></div>
		</div>

		<div class="form-floating mb-1">
		  <input type="text" class="form-control" id="ishort" name="short" value="<?php echo e(old('short') ?? ''); ?>" placeholder="<?php echo app('translator')->get('posts.placeholder_short'); ?>">
		  <label for="ishort"><?php echo app('translator')->get('posts.datafield_short'); ?></label>
		  <div class="invalid-feedback"></div>
		</div>

		<div class="form-floating1 mb-1">
		   <label for="ibody"><?php echo app('translator')->get('posts.datafield_body'); ?></label>
		   <textarea class="form-control hr-18" id="ibody" name="body" rows="9" placeholder="<?php echo app('translator')->get('posts.placeholder_body'); ?>"><?php echo old('body') ?? __('posts.placeholder_body'); ?></textarea>

		  <div class="invalid-feedback"></div>
		</div>
		<div class="row">
		<div class="col">
		<div class="form-floating">
		  <select class="form-select" id="ilanguage" aria-label="Floating label select example">
			<?php $__currentLoopData = getLanguagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iso2=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($iso2); ?>" <?php if( $iso2=='en' ): ?> SELECTED <?php endif; ?>><?php echo e(substr($title,0, strlen($title) -3)); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </select>
		  <label for="floatingSelect">Works with selects</label>
		</div>
		</div>
		<div class="col">
			<div class="form-check form-switch">
			  <input class="form-check-input" type="checkbox" role="switch" checked name="is_published" id="iis_published">
			  <label class="form-check-label" for="iis_published"><?php echo app('translator')->get('posts.datafield_is_published'); ?></label>
			</div>

			<div class="form-check form-switch">
			  <input class="form-check-input" type="checkbox" role="switch" name="is_featured" id="iis_featured">
			  <label class="form-check-label" for="iis_featured"><?php echo app('translator')->get('posts.datafield_is_featured'); ?></label>
			</div>
			<div class="form-check form-switch">
			  <input class="form-check-input" type="checkbox" role="switch" name="is_pinned" id="iis_pinned">
			  <label class="form-check-label" for="iis_pinned"><?php echo app('translator')->get('posts.datafield_is_pinned'); ?></label>
			</div>
			<div class="form-check form-switch">
			  <input class="form-check-input" type="checkbox" role="switch" name="is_commentable" id="iis_commentable">
			  <label class="form-check-label" for="iis_commentable"><?php echo app('translator')->get('posts.datafield_is_commentable'); ?></label>
			</div>
			<div class="form-check form-switch">
			  <input class="form-check-input" type="checkbox" role="switch" name="has_roles" id="ihas_roles">
			  <label class="form-check-label" for="ihas_roles"><?php echo app('translator')->get('posts.datafield_has_roles'); ?></label>
			</div>
			<div class="form-check form-switch">
			  <input class="form-check-input" type="checkbox" role="switch" checked name="is_editable" id="iis_editable">
			  <label class="form-check-label" for="iis_editable"><?php echo app('translator')->get('posts.datafield_is_editable'); ?></label>
			</div>
			<div class="form-check form-switch">
			  <input class="form-check-input" type="checkbox" role="switch" checked name="is_deleteable" id="iis_deleteable">
			  <label class="form-check-label" for="iis_deleteable"><?php echo app('translator')->get('posts.datafield_is_deleteable'); ?></label>
			</div>
		</div>
	  </div>

	</div>
	<div class="card-footer text-end">
		<button class="btn btn-primary" type="submit"><?php echo app('translator')->get('index.action_save'); ?></button>
		<a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary"><?php echo app('translator')->get('index.action_cancel'); ?></a>
	</div>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.ckeditor.com/4.20.0/standard-all/ckeditor.js"></script>


<script>
    CKEDITOR.replace('ibody', {
      removeButtons: 'PasteFromWord'
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/dashboard/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\alsahaba\resources\views/posts/create.blade.php ENDPATH**/ ?>