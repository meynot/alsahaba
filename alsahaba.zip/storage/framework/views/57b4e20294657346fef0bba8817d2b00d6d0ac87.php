

<?php $__env->startSection('breadcrumb'); ?>
   <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('backend.breadcrumbs_dashboard'); ?></a> / <?php echo app('translator')->get('posts.header_browse'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header"><h3 class="float-start"><?php echo app('translator')->get('posts.header_browse'); ?></h3><div class="float-end"><a class="btn btn-success" href="<?php echo e(route('posts.create')); ?>"><?php echo app('translator')->get('index.action_create'); ?></a></div></div>
	<div class="card-body">
	<table class="table table-striped table-hover">
	  <thead>
		<tr"><th><?php echo app('translator')->get('posts.datafield_title'); ?></th><th><?php echo app('translator')->get('posts.datafield_is_published'); ?></th><th><?php echo app('translator')->get('posts.datafield_is_featured'); ?></th><th><?php echo app('translator')->get('posts.datafield_is_pinned'); ?></th>
	  </thead>
	  <tbody>
  <?php if( $rows->count() > 0 ): ?>
		  
	  <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr role="button" onclick="window.location.replace('<?php echo e(route('posts.show', $row->id)); ?>');"><td><?php echo e($row->title); ?></td><td><?php echo e($row->is_published ? 'yes' : 'no'); ?></td><td><?php echo e($row->is_featured); ?></td><td><?php echo e($row->pinned); ?></td></tr>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
  <?php else: ?>
		<tr><td colspan="4"><?php echo app('translator')->get('index.no_records_found'); ?></td></tr>
  <?php endif; ?>
	  </tbody>
	</table>
	</div>
	<div class="card-footer">
		<?php echo $rows->links(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/dashboard/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\alsahaba\resources\views/posts/index.blade.php ENDPATH**/ ?>