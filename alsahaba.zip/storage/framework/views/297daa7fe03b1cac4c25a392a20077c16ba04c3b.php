


<?php $__env->startSection('breadcrumb'); ?>
   <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('backend.breadcrumbs_dashboard'); ?></a> / <a href="<?php echo e(route('users.index')); ?>"><?php echo app('translator')->get('users.header_browse'); ?></a> / <?php echo app('translator')->get('users.header_show'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="card-header"><h3 class="float-start"><?php echo app('translator')->get('users.header_create'); ?></h3><div class="float-end"></div></div>
	<div class="card-body">
	  <div class="border rounded p-1 mb-1">
	   <div class="bg-light p-1"><?php echo app('translator')->get('users.datafield_name'); ?></div>
	   <div><?php echo e($user->name); ?></div>
	  </div>
	  <div class="border rounded p-1 mb-1">
	   <div class="bg-light p-1"><?php echo app('translator')->get('users.datafield_email'); ?></div>
	   <div><?php echo e($user->email); ?></div>
	  </div>
	  <div class="">
	  
	  <span class="badge <?php if($user->is_active): ?> text-bg-success <?php else: ?> badge text-bg-secondary <?php endif; ?>"><?php echo app('translator')->get('users.datafield_is_active'); ?></span>
	  
	  <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  <span class="badge text-bg-success"><?php echo e($role->name); ?></span>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  <span class="badge text-bg-primary"><?php echo e(__('index.title', [], $user->language)); ?></span>
	  
	  
	  <?php if($user->facebook): ?> <a href="<?php echo e($user->facebook); ?>"><i class="fa fa-facebook fa-2x p-1 border rounded"></i></a> <?php endif; ?>
	  <?php if($user->twitter): ?> <a href="<?php echo e($user->twitter); ?>"><i class="fa fa-twitter fa-2x p-1 border rounded"></i></a> <?php endif; ?>
	  <?php if($user->instagram): ?> <a href="<?php echo e($user->instagram); ?>"><i class="fa fa-instagram fa-2x p-1 border rounded"></i></a> <?php endif; ?>
	  
	  </div>
	</div>
	<div class="card-footer text-end">
		<a class="btn btn-warning" href="<?php echo e(route('users.edit', $user->id)); ?>"><?php echo app('translator')->get('index.action_edit'); ?></a>
		<a class="btn btn-danger" href="<?php echo e(route('users.todelete', $user->id)); ?>"><?php echo app('translator')->get('index.action_delete'); ?></a>
		<a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary"><?php echo app('translator')->get('index.action_cancel'); ?></a>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend/dashboard/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\alsahaba\resources\views/users/show.blade.php ENDPATH**/ ?>