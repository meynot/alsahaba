

<?php $__env->startSection('breadcrumb'); ?>
   <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('backend.breadcrumbs_dashboard'); ?></a> / <?php echo app('translator')->get('users.header_browse'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header"><h3 class="float-start"><?php echo app('translator')->get('users.header_browse'); ?></h3><div class="float-end"><a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"><?php echo app('translator')->get('index.action_create'); ?></a></div></div>
	<div class="card-body">
	<table class="table table-striped table-hover">
	  <thead>
		<tr"><th><?php echo app('translator')->get('users.datafield_name'); ?></th><th><?php echo app('translator')->get('users.datafield_email'); ?></th><th><?php echo app('translator')->get('users.datafield_is_active'); ?></th><th><?php echo app('translator')->get('users.datafield_roles'); ?></th>
	  </thead>
	  <tbody>
	  <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr role="button" onclick="window.location.replace('<?php echo e(route('users.show', $row->id)); ?>');"><td><?php echo e($row->name); ?></td><td><?php echo e($row->email); ?></td><td><span class="badge <?php if($row->is_active): ?> text-bg-success <?php else: ?> text-bg-secondary <?php endif; ?>"><?php echo app('translator')->get('users.datafield_is_active'); ?></span></td><td><?php $__currentLoopData = $row->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <span class=""><?php echo e($role->name); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td></tr>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  </tbody>
	  <tfoot>
		<tr><td colspan="4"><?php echo e($rows->links()); ?></td></tr>
	  </tfoot>
	</table>
	</div>
	<div class="card-footer">
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/dashboard/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\alsahaba\resources\views/users/index.blade.php ENDPATH**/ ?>