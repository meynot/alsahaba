


<?php $__env->startSection('breadcrumb'); ?>
   <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('backend.breadcrumbs_dashboard'); ?></a> / <a href="<?php echo e(route('users.index')); ?>"><?php echo app('translator')->get('users.header_browse'); ?></a> / <?php echo app('translator')->get('users.header_edit'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header"><h3 class="float-start"><?php echo app('translator')->get('users.header_edit'); ?></h3><div class="float-end"></div></div>
	<form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>
	<div class="card-body">
		<div class="form-floating mb-1">
		  <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="iname" name="name" value="<?php echo e($user->name ?? old('name')); ?>" placeholder="<?php echo app('translator')->get('users.placeholder_name'); ?>">
		  <label for="iname"><?php echo app('translator')->get('users.datafield_name'); ?></label>
			<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		  
		</div>
		<div class="row">
		 <div class="col">
		  <div class="form-floating mb-1">
		   <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ipassword" name="password" value="<?php echo e(old('password') ?? ''); ?>" placeholder="<?php echo app('translator')->get('users.placeholder_password'); ?>">
		   <label for="ipassword"><?php echo app('translator')->get('users.datafield_password'); ?></label>
			<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		  
		  </div>
		 </div>
		 <div class="col">
		  <div class="form-floating mb-1">
		   <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ipassword_confirmation" name="password_confirmation" value="<?php echo e(old('password_confirmation') ?? ''); ?>" placeholder="<?php echo app('translator')->get('users.placeholder_password_confirmation'); ?>">
		   <label for="ipassword_confirmation"><?php echo app('translator')->get('users.datafield_password_confirmation'); ?></label>
			<?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		  
		  </div>
		 </div>
		</div>

		<div class="form-floating mb-1">
		  <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="iemail" name="email" value="<?php echo e($user->email ?? old('email')); ?>" placeholder="<?php echo app('translator')->get('users.placeholder_email'); ?>">
		  <label for="iemail"><?php echo app('translator')->get('users.datafield_email'); ?></label>
			<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		  
		</div>

		<div class="form-floating mb-1">
		  <input type="text" class="form-control <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ifacebook" name="facebook" value="<?php echo e($user->facebook ?? old('facebook')); ?>" placeholder="<?php echo app('translator')->get('users.placeholder_facebook'); ?>">
		  <label for="ifacebook"><?php echo app('translator')->get('users.datafield_facebook'); ?></label>
			<?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		  
		</div>

		<div class="form-floating mb-1">
		  <input type="text" class="form-control <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="itwitter" name="twitter" value="<?php echo e($user->twitter ?? old('twitter')); ?>" placeholder="<?php echo app('translator')->get('users.placeholder_twitter'); ?>">
		  <label for="itwitter"><?php echo app('translator')->get('users.datafield_twitter'); ?></label>
			<?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		  
		</div>

		<div class="form-floating mb-1">
		  <input type="text" class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="iinstagram" name="instagram" value="<?php echo e($user->instagram ?? old('instagram')); ?>" placeholder="<?php echo app('translator')->get('users.placeholder_instagram'); ?>">
		  <label for="iinstagram"><?php echo app('translator')->get('users.datafield_instagram'); ?></label>
			<?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<div class="invalid-feedback"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		  
		</div>

		<div class="row">
		 <div class="col">
		  <div class="form-floating">
		   <select class="form-select <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="ilanguage" aria-label="Floating label select example">
		   
			<?php $__currentLoopData = getLanguagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iso2=>$title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($iso2); ?>" <?php if( $iso2==$user->language ): ?> SELECTED <?php endif; ?>><?php echo e(substr($title,0, strlen($title) -3)); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   </select>
		   <label for="floatingSelect"><?php echo app('translator')->get('users.datafield_language'); ?></label>
		  </div>
		 </div>
		 
		<div class="col">
		  <div class="form-floating">
		   <select class="form-select <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="roles" id="iroles" aria-label="Floating label select example">
			<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($role->id); ?>" <?php if($user->hasRole($role)): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   </select>
		   <label for="floatingSelect"><?php echo app('translator')->get('users.datafield_roles'); ?></label>
		</div>
	  </div>
	 <div class="form-check form-switch">
	  <input class="form-check-input" type="checkbox" role="switch" name="is_active" id="iis_active" <?php if($user->is_active == true): ?> checked <?php endif; ?> />
	  <label class="form-check-label" for="iis_active"><?php echo app('translator')->get('users.datafield_is_active'); ?></label>
	 </div>

	</div>
	<div class="card-footer text-end">
		<button class="btn btn-primary" type="submit"><?php echo app('translator')->get('index.action_save'); ?></button>
		<a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary"><?php echo app('translator')->get('index.action_cancel'); ?></a>
	</div>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.ckeditor.com/4.20.0/standard-all/ckeditor.js"></script>


<script>
    CKEDITOR.replace('ibody', {
      removeButtons: 'PasteFromWord'
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/dashboard/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\alsahaba\resources\views/users/edit.blade.php ENDPATH**/ ?>