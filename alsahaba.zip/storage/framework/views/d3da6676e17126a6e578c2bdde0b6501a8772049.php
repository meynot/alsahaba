

<?php $__env->startSection('breadcrumb'); ?>
   <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('backend.breadcrumbs_dashboard'); ?></a> / <?php echo app('translator')->get('settings.header_browse'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header"><h3 class="float-start"><?php echo app('translator')->get('settings.header_browse'); ?></h3></div>
	<div class="card-body">
		Under construction
	</div>
	<div class="card-footer"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/dashboard/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\alsahaba\resources\views/settings/index.blade.php ENDPATH**/ ?>