

<?php $__env->startSection('breadcrumb'); ?>
   <?php echo app('translator')->get('backend.breadcrumbs_dashboard'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header">Welcome onboard</div>
	<div class="card-body">
	<div>TODO</div>
	Reports should be add here for posts, files to download, downloads, views ..etc
	</div>
	<div class="card-footer">
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/dashboard/layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\alsahaba\resources\views/backend/dashboard/index.blade.php ENDPATH**/ ?>